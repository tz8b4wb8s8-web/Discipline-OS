# DISCIPLINE OS

A React + TypeScript + Vite starter for a personal productivity and academic execution dashboard.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Create a production build with:

```bash
npm run build
```

## Current implementation

- Dark responsive dashboard and navigation
- Task creation and completion
- Habit checklist
- Focus timer
- Academic subject overview
- ManageBac integration setup/status UI
- Seven-day execution chart
- Browser-local persistence for demo tasks and habits

## Important limitations

This is an initial frontend scaffold, not a production deployment. Data currently persists in the browser's localStorage. Authentication, Supabase persistence, server-side AI, notifications and the live ManageBac API connection have not yet been implemented.

ManageBac requires school-authorised API access. Do not put ManageBac credentials or API tokens in frontend code. A production integration must be implemented server-side with secure secrets and the exact endpoints/permissions confirmed against the school's API access.
